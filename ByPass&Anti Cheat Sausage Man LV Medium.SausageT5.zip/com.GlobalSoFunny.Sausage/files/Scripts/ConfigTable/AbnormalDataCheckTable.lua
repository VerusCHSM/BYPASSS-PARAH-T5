local AbnormalDataCheckTable = class({}, Assets.req("Scripts.ConfigTable.Base.AbnormalDataCheckTableBase"))

--------------------------------------------自动生成--------------------------------------------

return AbnormalDataCheckTable
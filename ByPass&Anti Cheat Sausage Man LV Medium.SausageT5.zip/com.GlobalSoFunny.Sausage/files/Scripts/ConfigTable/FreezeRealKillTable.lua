local FreezeRealKillTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeRealKillTableBase"))

--------------------------------------------自动生成--------------------------------------------

return FreezeRealKillTable